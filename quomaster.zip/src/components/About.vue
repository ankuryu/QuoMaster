<template>
  <div class="about container">
    <h1 class="page-header">About</h1>
    <p>This is a Quotation manager app built with the Vue.js framework</p>
    <p>Version 1.0.0</p>
  </div>
</template>

<script>
export default {
  name: 'about',
  data () {
    return {
      
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
