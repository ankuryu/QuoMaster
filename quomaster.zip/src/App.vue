<template>
  <div id="app">
   TEST
  </div>
</template>

<script>

export default {
  name: 'app',
  components: {
   
  }
}
</script>

<style>

</style>
